package parser;

import java.util.*;
import java.util.regex.*;

public class ResourceParser {

    public static List<String> extractCSS(String html) {
        List<String> cssList = new ArrayList<>();
        Pattern pattern = Pattern.compile("<link[^>]+href=\"([^\"]+)\"");
        Matcher matcher = pattern.matcher(html);

        while (matcher.find()) {
            String link = matcher.group(1);
            if (link.endsWith(".css")) {
                cssList.add(link);
            }
        }
        return cssList;
    }

    public static List<String> extractJS(String html) {
        List<String> jsList = new ArrayList<>();
        Pattern pattern = Pattern.compile("<script[^>]+src=\"([^\"]+)\"");
        Matcher matcher = pattern.matcher(html);

        while (matcher.find()) {
            jsList.add(matcher.group(1));
        }
        return jsList;
    }

    public static List<String> extractImages(String html) {
        List<String> imgList = new ArrayList<>();
        Pattern pattern = Pattern.compile("<img[^>]+src=\"([^\"]+)\"");
        Matcher matcher = pattern.matcher(html);

        while (matcher.find()) {
            imgList.add(matcher.group(1));
        }
        return imgList;
    }
}