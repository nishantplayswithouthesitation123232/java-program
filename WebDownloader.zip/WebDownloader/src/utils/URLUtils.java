package utils;

import java.net.URL;

public class URLUtils {

    public static String getAbsoluteURL(String baseURL, String resource) {
        try {
            URL base = new URL(baseURL);
            URL absolute = new URL(base, resource);
            return absolute.toString();
        } catch (Exception e) {
            return null;
        }
    }
}