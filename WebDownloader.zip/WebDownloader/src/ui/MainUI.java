package ui;

import javax.swing.*;
import java.awt.*;
import downloader.HtmlDownloader;
import parser.ResourceParser;
import downloader.FileDownloader;
import utils.URLUtils;

public class MainUI extends JFrame {

    private JTextField urlField;
    private JButton downloadBtn;
    private JProgressBar progressBar;
    private JTextArea logArea;
    private JLabel statusLabel;

    public MainUI() {
        setTitle("Web Page Downloader");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setupUI();
    }

    private void setupUI() {

        // 🔹 Top Panel
        JPanel topPanel = new JPanel(new BorderLayout(10, 10));

        urlField = new JTextField();
        downloadBtn = new JButton("Download");

        topPanel.add(new JLabel("URL:"), BorderLayout.WEST);
        topPanel.add(urlField, BorderLayout.CENTER);
        topPanel.add(downloadBtn, BorderLayout.EAST);

        // 🔹 Log Area
        logArea = new JTextArea();
        logArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(logArea);

        // 🔹 Bottom Panel
        JPanel bottomPanel = new JPanel(new BorderLayout());

        progressBar = new JProgressBar();
        statusLabel = new JLabel("Idle");

        bottomPanel.add(progressBar, BorderLayout.CENTER);
        bottomPanel.add(statusLabel, BorderLayout.SOUTH);

        // 🔹 Frame Layout
        setLayout(new BorderLayout(10, 10));
        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        // 🔥 Button Action
        downloadBtn.addActionListener(e -> onDownload());
    }

   private void onDownload() {
    String url = urlField.getText().trim();

    if (url.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Enter URL");
        return;
    }

    logArea.append("Downloading HTML...\n");
    statusLabel.setText("Downloading...");

   new Thread(() -> {
    String html = downloader.HtmlDownloader.downloadHTML(url);

    if (html != null) {
        downloader.HtmlDownloader.saveHTML(html, "downloads");

        logArea.append("HTML downloaded\n");

        // 🔥 Extract resources
        var cssList = ResourceParser.extractCSS(html);
        var jsList = ResourceParser.extractJS(html);
        var imgList = ResourceParser.extractImages(html);

        logArea.append("CSS found: " + cssList.size() + "\n");
        logArea.append("JS found: " + jsList.size() + "\n");
        logArea.append("Images found: " + imgList.size() + "\n");

        // 🔥 Download CSS
       for (String css : cssList) {
    String fullURL = URLUtils.getAbsoluteURL(url, css);

    System.out.println("CSS URL: " + fullURL);

    if (fullURL != null && fullURL.startsWith("http")) {
        downloader.FileDownloader.downloadFile(
                fullURL,
                "downloads/css/" + css.hashCode() + ".css"
        );
    }
}

        // 🔥 Download JS
      for (String js : jsList) {
    String fullURL = URLUtils.getAbsoluteURL(url, js);

    System.out.println("JS URL: " + fullURL);

    if (fullURL != null && fullURL.startsWith("http")) {
        downloader.FileDownloader.downloadFile(
                fullURL,
                "downloads/js/" + js.hashCode() + ".js"
        );
    }
}

        // 🔥 Download Images
        for (String img : imgList) {
    String fullURL = URLUtils.getAbsoluteURL(url, img);

    System.out.println("IMG URL: " + fullURL);

    if (fullURL != null && fullURL.startsWith("http")) {
        downloader.FileDownloader.downloadFile(
                fullURL,
                "downloads/images/" + img.hashCode() + ".jpg"
        );
    }
}

       downloader.FileDownloader.shutdown();

SwingUtilities.invokeLater(() -> {
    logArea.append("All resources downloading (multithreaded)...\n");
    statusLabel.setText("Done");
    progressBar.setValue(100);
});

    } else {
        SwingUtilities.invokeLater(() -> {
            logArea.append("Download failed\n");
            statusLabel.setText("Error");
        });
    }
}).start();
   }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new MainUI().setVisible(true);
        });
    }
}