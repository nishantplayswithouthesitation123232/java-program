package downloader;

import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class FileDownloader {

    private static final ExecutorService executor = Executors.newFixedThreadPool(5);

    public static void downloadFile(String fileURL, String savePath) {
        executor.submit(() -> {
            try {
                URL url = new URL(fileURL);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                conn.setRequestProperty("User-Agent",
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64)");

                int responseCode = conn.getResponseCode();

                if (responseCode != 200) {
                    System.out.println("Skipped (HTTP " + responseCode + "): " + fileURL);
                    return;
                }

                InputStream input = conn.getInputStream();

                File file = new File(savePath);
                file.getParentFile().mkdirs();

                FileOutputStream output = new FileOutputStream(file);

                byte[] buffer = new byte[4096];
                int bytesRead;

                while ((bytesRead = input.read(buffer)) != -1) {
                    output.write(buffer, 0, bytesRead);
                }

                output.close();
                input.close();

                System.out.println("Downloaded: " + fileURL);

            } catch (Exception e) {
                System.out.println("Failed: " + fileURL);
            }
        });
    }

    public static void shutdown() {
        executor.shutdown();
        try {
            if (!executor.awaitTermination(60, TimeUnit.SECONDS)) {
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
        }
    }
}