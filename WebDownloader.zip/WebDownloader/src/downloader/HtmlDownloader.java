package downloader;

import java.io.*;
import java.net.*;

public class HtmlDownloader {

    public static String downloadHTML(String urlString) {
        StringBuilder html = new StringBuilder();

        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            conn.setRequestMethod("GET");

            // 🔥 Makes request look like browser
            conn.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64)");

            conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9");

            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);

            int responseCode = conn.getResponseCode();

            InputStream inputStream;

            // ✅ Handle success + error properly
            if (responseCode >= 200 && responseCode < 300) {
                inputStream = conn.getInputStream();
            } else {
                inputStream = conn.getErrorStream();
                System.out.println("HTTP Error Code: " + responseCode);
            }

            if (inputStream == null) return null;

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(inputStream)
            );

            String line;
            while ((line = reader.readLine()) != null) {
                html.append(line).append("\n");
            }

            reader.close();

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

        return html.toString();
    }

    public static void saveHTML(String html, String folderPath) {
        try {
            File folder = new File(folderPath);
            if (!folder.exists()) {
                folder.mkdirs();
            }

            File file = new File(folderPath + "/index.html");

            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            writer.write(html);
            writer.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}